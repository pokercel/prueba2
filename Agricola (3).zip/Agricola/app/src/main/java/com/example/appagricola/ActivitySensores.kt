package com.example.appagricola

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class ActivitySensores : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sensores)

        val spinnerUbicaciones = findViewById<Spinner>(R.id.spinnerUbicaciones)
        val spinnerTipoSensor = findViewById<Spinner>(R.id.spinnerTipoSensor)
        val editTextNombre = findViewById<EditText>(R.id.editTextNombreSensor)
        val editTextDescripcion = findViewById<EditText>(R.id.editTextDescripcionSensor)
        val editTextIdeal = findViewById<EditText>(R.id.editTextIdealSensor)
        val buttonGuardar = findViewById<Button>(R.id.buttonGuardarSensor)

        // Configurar el spinner de ubicaciones
        val ubicacionNombres = DataStorage.ubicaciones.map { it.nombre }
        val adapterUbicaciones = ArrayAdapter(this, android.R.layout.simple_spinner_item, ubicacionNombres)
        adapterUbicaciones.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerUbicaciones.adapter = adapterUbicaciones

        // Configurar el spinner de tipo de sensor con "Temperatura" y "Humedad"
        val tiposSensores = listOf("Temperatura", "Humedad")
        val adapterTipos = ArrayAdapter(this, android.R.layout.simple_spinner_item, tiposSensores)
        adapterTipos.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerTipoSensor.adapter = adapterTipos

        buttonGuardar.setOnClickListener {
            val nombre = editTextNombre.text.toString()
            val descripcion = editTextDescripcion.text.toString()
            val ideal = editTextIdeal.text.toString().toFloatOrNull() ?: 0f
            val ubicacionSeleccionada = DataStorage.ubicaciones[spinnerUbicaciones.selectedItemPosition]

            // Validación de campos obligatorios
            if (nombre.isEmpty() || descripcion.isEmpty()) {
                Toast.makeText(this, "Todos los campos deben ser rellenados", Toast.LENGTH_SHORT).show()
            } else if (nombre.length !in 5..15) {
                Toast.makeText(this, "El nombre debe tener entre 5 y 15 caracteres", Toast.LENGTH_SHORT).show()
            } else if (descripcion.length > 30) {
                Toast.makeText(this, "La descripción debe tener un máximo de 30 caracteres", Toast.LENGTH_SHORT).show()
            } else {
                // Crear y guardar el sensor
                val sensor = DataModels.Sensor(
                    id = DataStorage.sensores.size + 1,
                    nombre = nombre,
                    descripcion = descripcion,
                    ideal = ideal,
                    tipo = DataModels.Tipo(id = spinnerTipoSensor.selectedItemPosition + 1, nombre = spinnerTipoSensor.selectedItem.toString()),
                    ubicacion = ubicacionSeleccionada
                )
                DataStorage.sensores.add(sensor)

                // Limpiar los campos después de guardar
                editTextNombre.text.clear()
                editTextDescripcion.text.clear()
                editTextIdeal.text.clear()

                Toast.makeText(this, "Sensor guardado correctamente", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
