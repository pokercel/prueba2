// SensoresAdapter.kt
package com.example.appagricola.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.appagricola.R
import com.example.appagricola.models.Sensor

class SensoresAdapter(private val sensores: List<Sensor>) : RecyclerView.Adapter<SensoresAdapter.SensorViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SensorViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.activity_item_sensor, parent, false)
        return SensorViewHolder(view)
    }

    override fun onBindViewHolder(holder: SensorViewHolder, position: Int) {
        val sensor = sensores[position]
        holder.bind(sensor)
    }

    override fun getItemCount(): Int {
        return sensores.size
    }

    class SensorViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val nombreTextView: TextView = itemView.findViewById(R.id.nombreSensorTextView)
        private val descripcionTextView: TextView = itemView.findViewById(R.id.descripcionSensorTextView)
        private val tipoTextView: TextView = itemView.findViewById(R.id.tipoSensorTextView)
        private val idealTextView: TextView = itemView.findViewById(R.id.idealSensorTextView)

        fun bind(sensor: Sensor) {
            nombreTextView.text = sensor.nombre
            descripcionTextView.text = sensor.descripcion
            tipoTextView.text = sensor.tipo.nombre
            idealTextView.text = sensor.ideal.toString()
        }
    }
}
