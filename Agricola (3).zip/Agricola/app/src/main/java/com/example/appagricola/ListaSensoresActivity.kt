package com.example.appagricola

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.appagricola.adapters.SensoresAdapter
import com.example.appagricola.datos.DataStorage
import com.example.appagricola.models.Sensor

class ListaSensoresActivity : AppCompatActivity() {

    private lateinit var sensoresRecyclerView: RecyclerView
    private lateinit var sensoresAdapter: SensoresAdapter
    private lateinit var sensores: List<Sensor>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sensores)

        // Inicializar RecyclerView
        sensoresRecyclerView = findViewById(R.id.listaSensoresRecyclerView)
        sensoresRecyclerView.layoutManager = LinearLayoutManager(this)

        // Obtener la lista de sensores desde DataStorage
        sensores = DataStorage.getInstance().sensores
        sensoresAdapter = SensoresAdapter(sensores)
        sensoresRecyclerView.adapter = sensoresAdapter
    }
}
