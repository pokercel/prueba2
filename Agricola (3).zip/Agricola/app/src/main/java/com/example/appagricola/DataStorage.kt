package com.example.appagricola

object DataStorage {
    val ubicaciones = mutableListOf<DataModels.Ubicacion>()
    val sensores = mutableListOf<DataModels.Sensor>()
    var nextUbicacionId = 1
    var nextSensorId = 1
    val registros = mutableListOf<DataModels.Registro>()

}

