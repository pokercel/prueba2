package com.example.appagricola.models

data class Tipo(
    val id: Int,
    val nombre: String
)
