// LocationManager.kt
package com.example.appagricola.manager

import android.content.Context
import android.content.Intent
import com.example.appagricola.ActivityUbicaciones

class LocationManager(private val context: Context) {
    fun openLocationActivity() {
        val intent = Intent(context, ActivityUbicaciones::class.java)
        context.startActivity(intent)
    }
}
