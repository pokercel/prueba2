// SensorManager.kt
package com.example.appagricola.manager

import android.content.Context
import android.content.Intent
import com.example.appagricola.ActivitySensores

class SensorManager(private val context: Context) {
    fun openSensorActivity() {
        val intent = Intent(context, ActivitySensores::class.java)
        context.startActivity(intent)
    }
}
