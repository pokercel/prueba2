package com.example.appagricola.models

data class Ubicacion(
    val id: Int,
    val nombre: String
)
