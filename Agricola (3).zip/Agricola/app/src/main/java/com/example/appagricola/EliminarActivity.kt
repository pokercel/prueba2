package com.example.appagricola

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class EliminarActivity : AppCompatActivity() {

    private lateinit var spinnerElimin: Spinner
    private lateinit var btnEliminarUbicacion: Button


    private val ubicacionesYSensores = mutableMapOf(
        "Ubicación 1" to "Sensor 1",
        "Ubicación 2" to "Sensor 2",
        "Ubicación 3" to "Sensor 3"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_eliminar)


        spinnerUbicacionesEliminar = findViewById(R.id.spinnerUbicacionesEliminar)
        btnEliminarUbicacion = findViewById(R.id.btnEliminarUbicacion)


        val ubicaciones = ubicacionesYSensores.keys.toList() // Lista de ubicaciones
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, ubicaciones)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerUbicacionesEliminar.adapter = adapter


        btnEliminarUbicacion.setOnClickListener {
            eliminarUbicacionYSensor(adapter)
        }
    }

    private fun eliminarUbicacionYSensor(adapter: ArrayAdapter<String>) {

        val ubicacionSeleccionada = spinnerUbicacionesEliminar.selectedItem.toString()


        if (ubicacionesYSensores.containsKey(ubicacionSeleccionada)) {
            ubicacionesYSensores.remove(ubicacionSeleccionada)
            adapter.notifyDataSetChanged()


            Toast.makeText(this, "Ubicación '$ubicacionSeleccionada' y su sensor fueron eliminados", Toast.LENGTH_SHORT).show()
        } else {

            Toast.makeText(this, "Ubicación no registrada o no disponible", Toast.LENGTH_SHORT).show()
        }
    }
}